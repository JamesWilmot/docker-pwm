PWM Readme
----------

PWM is an open source Password Self Service application.   Instructions, downloads, and project information
can be found at the PWM Project website:

http://code.google.com/p/pwm

